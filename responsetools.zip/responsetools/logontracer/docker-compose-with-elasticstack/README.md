# Docker Compose for LogonTracer

  Please check the wiki for more details.   
  https://github.com/JPCERTCC/LogonTracer/wiki/setup-with-docker-compose

## Usage
  ```shell
  $ docker-compose build
  $ docker-compose up -d
  ```
