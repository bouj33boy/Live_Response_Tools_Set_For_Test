# How to Use
## Security.evtx
  AD security event sample  
  ```
  $ python3 logontracer.py -e Security.evtx -z [TIMEZONE] -u [NEO4J_USER] -p [PASSWORD] -s [NEO4J_SERVER]
  ```
## graph.db.tar.gz
  neo4j database sample
  ```
  $ tar xvzf graph.db.tar.gz  -C [neo4j]/data/databases/
  ```
