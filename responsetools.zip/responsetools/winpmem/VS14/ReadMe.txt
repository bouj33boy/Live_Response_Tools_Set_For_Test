This directory contains the MSVC 14 project files for building the driver.
